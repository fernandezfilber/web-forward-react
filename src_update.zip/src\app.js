const express     = require('express');
const cors        = require('cors');
const helmet      = require('helmet');
const session     = require('express-session');
const { createClient } = require('ioredis');
require('dotenv').config();

// ── Sentry (debe ser el primero) ─────────────────────────────
const Sentry = require('@sentry/node');
if (process.env.SENTRY_DSN) {
  Sentry.init({
    dsn:         process.env.SENTRY_DSN,
    environment: process.env.NODE_ENV || 'development',
    tracesSampleRate: 0.2,
  });
}

const logger        = require('./config/logger');
const passport      = require('./config/passport');
const { connectDB, disconnectDB } = require('./config/database');
const { redis }                   = require('./config/redis');

const authRoutes    = require('./routes/auth');
const mediaRoutes   = require('./routes/media');
const commentRoutes = require('./routes/comments');
const adminRoutes   = require('./routes/admin');

const app  = express();
const PORT = process.env.PORT || 5000;

// ── Sentry request handler ────────────────────────────────────
if (process.env.SENTRY_DSN) {
  app.use(Sentry.Handlers.requestHandler());
  app.use(Sentry.Handlers.tracingHandler());
}

// ── Security ──────────────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({
  origin:      process.env.FRONTEND_URL || 'http://localhost',
  credentials: true,
}));

// ── Session (solo para flujo OAuth de Passport) ───────────────
app.use(session({
  secret:            process.env.SESSION_SECRET || 'fv_session_secret_cambiar',
  resave:            false,
  saveUninitialized: false,
  cookie: {
    secure:   process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge:   5 * 60 * 1000, // 5 minutos (solo para el callback OAuth)
  },
}));

// ── Passport ──────────────────────────────────────────────────
app.use(passport.initialize());
app.use(passport.session());

// ── General Middleware ────────────────────────────────────────
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.path} — ${req.ip}`);
  next();
});
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── Health Check ──────────────────────────────────────────────
app.get('/api/health', async (req, res) => {
  const redisOk = await redis.ping().then(() => true).catch(() => false);
  res.json({
    status:    'ok',
    timestamp: new Date().toISOString(),
    services:  { mysql: 'connected', redis: redisOk ? 'connected' : 'error' },
  });
});

// ── Routes ────────────────────────────────────────────────────
app.use('/api/auth',     authRoutes);
app.use('/api/media',    mediaRoutes);
app.use('/api/comments', commentRoutes);
app.use('/api/admin',    adminRoutes);

// ── Sentry error handler (antes del nuestro) ──────────────────
if (process.env.SENTRY_DSN) {
  app.use(Sentry.Handlers.errorHandler());
}

// ── 404 ───────────────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ error: 'Ruta no encontrada' }));

// ── Error Handler ─────────────────────────────────────────────
app.use((err, req, res, next) => {
  logger.error(`Error en ${req.method} ${req.path}: ${err.message}`);
  res.status(err.status || 500).json({ error: err.message || 'Error interno del servidor' });
});

// ── Start ─────────────────────────────────────────────────────
async function start() {
  try {
    await redis.connect().catch(() => {});
    await connectDB();
    app.listen(PORT, () => logger.info(`🚀 Backend corriendo en http://localhost:${PORT}`));
  } catch (err) {
    logger.error('Error al iniciar:', err.message);
    process.exit(1);
  }
}

start();

process.on('SIGINT', async () => {
  await disconnectDB();
  await redis.quit();
  process.exit(0);
});

module.exports = app;
